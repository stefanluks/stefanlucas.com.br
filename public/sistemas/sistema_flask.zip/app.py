from flask import Flask, render_template
import psycopg2
import psycopg2.extras

app = Flask(__name__)

DATABASE_URL = "postgresql://aulas_db_user:rKJwe73F7uO9Sn4oMBo3oHz3ldVN4bd2@dpg-d7nk3cugvqtc73ate8pg-a.oregon-postgres.render.com/loja_games_db"


def get_connection():
    return psycopg2.connect(DATABASE_URL)


@app.route("/")
def index():
    return render_template("index.html")

@app.route("/jogos")
def jogos():
    conn = get_connection()
    cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

    cursor.execute("""
        SELECT
            jogos.id,
            jogos.titulo,
            jogos.genero,
            jogos.preco,
            jogos.estoque,
            plataformas.nome AS plataforma
        FROM jogos
        INNER JOIN plataformas
        ON jogos.plataforma_id = plataformas.id
    """)

    dados = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template("jogos.html", jogos=dados)

@app.route("/clientes")
def clientes():
    conn = get_connection()
    cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

    cursor.execute("SELECT * FROM clientes")

    dados = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template("clientes.html", clientes=dados)


@app.route("/compras")
def compras():
    conn = get_connection()
    cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

    cursor.execute("""
        SELECT
            compras.id,
            clientes.nome AS cliente,
            jogos.titulo AS jogo,
            compras.quantidade,
            compras.valor_total,
            compras.data_compra
        FROM compras
        INNER JOIN clientes
        ON compras.cliente_id = clientes.id
        INNER JOIN jogos
        ON compras.jogo_id = jogos.id
    """)

    dados = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template("compras.html", compras=dados)


@app.route("/avaliacoes")
def avaliacoes():
    conn = get_connection()
    cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

    cursor.execute("""
        SELECT
            avaliacoes.id,
            clientes.nome AS cliente,
            jogos.titulo AS jogo,
            avaliacoes.nota,
            avaliacoes.comentario
        FROM avaliacoes
        INNER JOIN clientes
        ON avaliacoes.cliente_id = clientes.id
        INNER JOIN jogos
        ON avaliacoes.jogo_id = jogos.id
    """)

    dados = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template("avaliacoes.html", avaliacoes=dados)


@app.route("/plataformas")
def plataformas():
    conn = get_connection()
    cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

    cursor.execute("SELECT * FROM plataformas")

    dados = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template("plataformas.html", plataformas=dados)


if __name__ == "__main__":
    app.run(debug=True)