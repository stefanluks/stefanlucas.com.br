from flask import Flask, render_template, request, redirect, url_for, session, flash
import psycopg2
import psycopg2.extras

app = Flask(__name__)
app.secret_key = "fitinha_senai_2026"


def conectar():
    return psycopg2.connect(
        host="localhost",
        database="fitinha_db",
        user="postgres",
        password="Senai@26",
        port="5432"
    )


@app.route("/")
def index():
    if "usuario_id" not in session:
        return redirect(url_for("login"))

    conn = conectar()
    cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

    cursor.execute("""
        SELECT 
            v.id,
            v.titulo,
            v.descricao,
            v.url_capa,
            v.url_video,
            v.duracao,
            v.ano_lancamento,
            c.nome AS categoria,
            COUNT(f.id) AS total_favoritos
        FROM videos v
        INNER JOIN categorias c ON v.categoria_id = c.id
        LEFT JOIN favoritos f ON f.video_id = v.id
        GROUP BY v.id, c.nome
        ORDER BY v.id DESC;
    """)

    videos = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template("index.html", videos=videos)


@app.route("/cadastro", methods=["GET", "POST"])
def cadastro():
    if request.method == "POST":
        nome = request.form["nome"]
        email = request.form["email"]
        senha = request.form["senha"]

        conn = conectar()
        cursor = conn.cursor()

        try:
            cursor.execute("""
                INSERT INTO usuarios (nome, email, senha)
                VALUES (%s, %s, %s)
            """, (nome, email, senha))

            conn.commit()
            flash("Usuário cadastrado com sucesso!")
            return redirect(url_for("login"))

        except Exception as e:
            conn.rollback()
            flash("Erro ao cadastrar usuário. Verifique se o e-mail já existe.")

        finally:
            cursor.close()
            conn.close()

    return render_template("cadastro.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        senha = request.form["senha"]

        conn = conectar()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""
            SELECT * FROM usuarios
            WHERE email = %s AND senha = %s
        """, (email, senha))

        usuario = cursor.fetchone()

        cursor.close()
        conn.close()

        if usuario:
            session["usuario_id"] = usuario["id"]
            session["usuario_nome"] = usuario["nome"]
            return redirect(url_for("index"))
        else:
            flash("E-mail ou senha inválidos.")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/video/<int:id>")
def detalhe_video(id):
    if "usuario_id" not in session:
        return redirect(url_for("login"))

    conn = conectar()
    cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

    cursor.execute("""
        SELECT 
            v.id,
            v.titulo,
            v.descricao,
            v.url_video,
            v.url_capa,
            v.duracao,
            v.ano_lancamento,
            c.nome AS categoria,
            COUNT(f.id) AS total_favoritos
        FROM videos v
        INNER JOIN categorias c ON v.categoria_id = c.id
        LEFT JOIN favoritos f ON f.video_id = v.id
        WHERE v.id = %s
        GROUP BY v.id, c.nome
    """, (id,))

    video = cursor.fetchone()

    cursor.execute("""
        SELECT * FROM favoritos
        WHERE usuario_id = %s AND video_id = %s
    """, (session["usuario_id"], id))

    favoritado = cursor.fetchone()

    cursor.close()
    conn.close()

    return render_template("video.html", video=video, favoritado=favoritado)


@app.route("/favoritar/<int:video_id>")
def favoritar(video_id):
    if "usuario_id" not in session:
        return redirect(url_for("login"))

    usuario_id = session["usuario_id"]

    conn = conectar()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT * FROM favoritos
        WHERE usuario_id = %s AND video_id = %s
    """, (usuario_id, video_id))

    favorito = cursor.fetchone()

    if favorito:
        cursor.execute("""
            DELETE FROM favoritos
            WHERE usuario_id = %s AND video_id = %s
        """, (usuario_id, video_id))
    else:
        cursor.execute("""
            INSERT INTO favoritos (usuario_id, video_id)
            VALUES (%s, %s)
        """, (usuario_id, video_id))

    conn.commit()
    cursor.close()
    conn.close()

    return redirect(url_for("detalhe_video", id=video_id))


@app.route("/favoritos")
def favoritos():
    if "usuario_id" not in session:
        return redirect(url_for("login"))

    conn = conectar()
    cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

    cursor.execute("""
        SELECT 
            v.id,
            v.titulo,
            v.descricao,
            v.url_capa,
            v.ano_lancamento,
            c.nome AS categoria,
            f.data_favorito
        FROM favoritos f
        INNER JOIN videos v ON f.video_id = v.id
        INNER JOIN categorias c ON v.categoria_id = c.id
        WHERE f.usuario_id = %s
        ORDER BY f.data_favorito DESC
    """, (session["usuario_id"],))

    videos = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template("favoritos.html", videos=videos)


@app.route("/ranking")
def ranking():
    if "usuario_id" not in session:
        return redirect(url_for("login"))

    conn = conectar()
    cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

    cursor.execute("""
        
    """)

    ranking = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template("ranking.html", ranking=ranking)


if __name__ == "__main__":
    app.run(debug=True)